<?php
add_action( 'widgets_init', 'zox_feat_load_widgets' );

function zox_feat_load_widgets() {
	register_widget( 'zox_feat_widget' );
}

class zox_feat_widget extends WP_Widget {

	/**
	 * Widget setup.
	 */
	function __construct() {
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'zox_feat_widget', 'description' => esc_html__('A widget that displays a single large post.', 'zoxpress') );

		/* Widget control settings. */
		$control_ops = array( 'width' => 250, 'height' => 350, 'id_base' => 'zox_feat_widget' );

		/* Create the widget. */
		parent::__construct( 'zox_feat_widget', esc_html__('ZoxPress: Featured Widget', 'zoxpress'), $widget_ops, $control_ops );
	}

	/**
	 * How to display the widget on the screen.
	 */
	function widget( $args, $instance ) {
		extract( $args );

		/* Our variables from the widget settings. */
		global $post;
		$title = apply_filters('widget_title', $instance['title'] );
		$content = $instance['content'];
		$width = $instance['width'];
		$enterslug = $instance['enterslug'];
		$exclude = $instance['exclude'];
		$bgcolor = $instance['bgcolor'];
		$txtcolor = $instance['txtcolor'];

		?>
			<?php if ($width == 'wide') { ?>
				<div class="zox-widget-width zox-widget-widthw zoxrel zox100 left">
			<?php } else { ?>
				<div class="zox-widget-width zox-widget-widths zoxrel zox100 left">
			<?php } ?>
			<?php if ($bgcolor == 'white') { ?>
				<?php if ($txtcolor == 'white') { ?>
					<div class="zox-widget-bg zox-widget-bgw zox-widget-txtw">
				<?php } else { ?>
					<div class="zox-widget-bg zox-widget-bgw">
				<?php } ?>
			<?php } else if ($bgcolor == 'gray') { ?>
				<?php if ($txtcolor == 'white') { ?>
					<div class="zox-widget-bg zox-widget-bgg zox-widget-txtw">
				<?php } else { ?>
					<div class="zox-widget-bg zox-widget-bgg">
				<?php } ?>
			<?php } else if ($bgcolor == 'black') { ?>
				<?php if ($txtcolor == 'white') { ?>
					<div class="zox-widget-bg zox-widget-bgb zox-widget-txtw">
				<?php } else { ?>
					<div class="zox-widget-bg zox-widget-bgb">
				<?php } ?>
			<?php } else if ($bgcolor == 'primary') { ?>
				<?php if ($txtcolor == 'white') { ?>
					<div class="zox-widget-bg zox-widget-bgp zox-widget-txtw">
				<?php } else { ?>
					<div class="zox-widget-bg zox-widget-bgp">
				<?php } ?>
			<?php } else if ($bgcolor == 'secondary') { ?>
				<?php if ($txtcolor == 'white') { ?>
					<div class="zox-widget-bg zox-widget-bgs zox-widget-txtw">
				<?php } else { ?>
					<div class="zox-widget-bg zox-widget-bgs">
				<?php } ?>
			<?php } else { ?>
				<?php if ($txtcolor == 'white') { ?>
					<div class="zox-widget-bg zox-widget-bg zox-widget-txtw">
				<?php } else { ?>
					<div class="zox-widget-bg zox-widget-bg">
				<?php } ?>
			<?php } ?>
		<?php

		/* Before widget (defined by themes). */
		echo html_entity_decode($before_widget);

		/* Display the widget title if one was input (before and after defined by themes). */
				if ( $title )
			echo html_entity_decode($before_title . $title . $after_title);

		?>
			<div class="zox-widget-feat-wrap">
				<div class="zox-widget-feat-main zox-div1 <?php $zox_skin = get_option('zox_skin'); $zox_over_style = get_option('zox_over_style');
						if ($zox_skin == "2") {
							echo "zox-o6";
						} else if ($zox_skin == "3" || $zox_skin == "4") {
							echo "zox-o1";
						} else if ($zox_skin == "9") {
							echo "zox-o3";
						} else {
							if ($zox_over_style == "1") {
								echo "zox-o1";
							} else if ($zox_over_style == "2") {
								echo "zox-o2";
							} else if ($zox_over_style == "3") {
								echo "zox-o3";
							} else if ($zox_over_style == "4") {
								echo "zox-o4";
							} else if ($zox_over_style == "5") {
								echo "zox-o5";
							} else if ($zox_over_style == "6") {
								echo "zox-o6";
							} else {
								echo "zox-o6";
							}
						} ?>">
					<?php if ($content == 'category') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php global $post; $recent = new WP_Query(array( 'category_name' => $enterslug, 'posts_per_page' => '1', 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); while($recent->have_posts()) : $recent->the_post(); $do_not_duplicate[] = $post->ID; ?>
								<?php get_template_part( 'parts/art', 'exlarge' ); ?>
							<?php endwhile; wp_reset_postdata(); ?>
						<?php } else { ?>
							<?php global $post; $recent = new WP_Query(array( 'category_name' => $enterslug, 'posts_per_page' => '1', 'ignore_sticky_posts'=> 1 )); while($recent->have_posts()) : $recent->the_post(); $do_not_duplicate[] = $post->ID; ?>
								<?php get_template_part( 'parts/art', 'exlarge' ); ?>
							<?php endwhile; wp_reset_postdata(); ?>
						<?php } ?>
					<?php } else if ($content == 'tag') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php global $post; $recent = new WP_Query(array( 'tag' => $enterslug, 'posts_per_page' => '1', 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); while($recent->have_posts()) : $recent->the_post(); $do_not_duplicate[] = $post->ID; ?>
								<?php get_template_part( 'parts/art', 'exlarge' ); ?>
							<?php endwhile; wp_reset_postdata(); ?>
						<?php } else { ?>
							<?php global $post; $recent = new WP_Query(array( 'tag' => $enterslug, 'posts_per_page' => '1', 'ignore_sticky_posts'=> 1 )); while($recent->have_posts()) : $recent->the_post(); $do_not_duplicate[] = $post->ID; ?>
								<?php get_template_part( 'parts/art', 'exlarge' ); ?>
							<?php endwhile; wp_reset_postdata(); ?>
						<?php } ?>
					<?php } else if ($content == 'video') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php global $post; query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-video' )), 'posts_per_page' => '1', 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); $do_not_duplicate[] = $post->ID; ?>
								<?php get_template_part( 'parts/art', 'exlarge' ); ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } else { ?>
							<?php global $post; query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-video' )), 'posts_per_page' => '1', 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); $do_not_duplicate[] = $post->ID; ?>
								<?php get_template_part( 'parts/art', 'exlarge' ); ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } ?>
					<?php } else if ($content == 'gallery') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php global $post; query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-gallery' )), 'posts_per_page' => '1', 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); $do_not_duplicate[] = $post->ID; ?>
								<?php get_template_part( 'parts/art', 'exlarge' ); ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } else { ?>
							<?php global $post; query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-gallery' )), 'posts_per_page' => '1', 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); $do_not_duplicate[] = $post->ID; ?>
								<?php get_template_part( 'parts/art', 'exlarge' ); ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } ?>
					<?php } else { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php global $post; query_posts(array( 'posts_per_page' => '1', 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); $do_not_duplicate[] = $post->ID; ?>
								<?php get_template_part( 'parts/art', 'exlarge' ); ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } else { ?>
							<?php global $post; query_posts(array( 'posts_per_page' => '1', 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); $do_not_duplicate[] = $post->ID; ?>
								<?php get_template_part( 'parts/art', 'exlarge' ); ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } ?>
					<?php } ?>
				</div><!--zox-widget-feat-main-->
			</div><!--zox-widget-feat-wrap-->
		<?php

		/* After widget (defined by themes). */
		echo html_entity_decode($after_widget);

		?>
			</div><!--zox-widget-bg-->
			</div><!--zox-widget-width-->
		<?php

	}

	/**
	 * Update the widget settings.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['content'] = strip_tags( $new_instance['content'] );
		$instance['width'] = strip_tags( $new_instance['width'] );
		$instance['enterslug'] = strip_tags( $new_instance['enterslug'] );
		$instance['exclude'] = strip_tags( $new_instance['exclude'] );
		$instance['bgcolor'] = strip_tags( $new_instance['bgcolor'] );
		$instance['txtcolor'] = strip_tags( $new_instance['txtcolor'] );

		return $instance;
	}

	function form( $instance ) {

		/* Set up some default widget settings. */
		$defaults = array( 'title' => 'Latest', 'content' => 'latest', 'style' => 'stand', 'width' => 'stand', 'exclude' => 'on', 'bgcolor' => 'none', 'txtcolor' => 'standard' );
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<!-- Widget Title: Text Input -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'title' )); ?>">Title:</label>
			<input id="<?php echo esc_html($this->get_field_id( 'title' )); ?>" name="<?php echo esc_html($this->get_field_name( 'title' )); ?>" value="<?php echo esc_html($instance['title']); ?>" style="width:90%;" />
		</p>

		<!-- Content -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id('content')); ?>">Choose Type of Content:</label>
			<select id="<?php echo esc_html($this->get_field_id('content')); ?>" name="<?php echo esc_html($this->get_field_name('content')); ?>" style="width:100%;">
				<option value='latest' <?php if ('latest' == $instance['content']) echo 'selected="selected"'; ?>>Latest</option>
				<option value='category' <?php if ('category' == $instance['content']) echo 'selected="selected"'; ?>>Category</option>
				<option value='tag' <?php if ('tag' == $instance['content']) echo 'selected="selected"'; ?>>Tag</option>
				<option value='video' <?php if ('video' == $instance['content']) echo 'selected="selected"'; ?>>Videos</option>
				<option value='gallery' <?php if ('gallery' == $instance['content']) echo 'selected="selected"'; ?>>Gallery</option>
			</select>
		</p>

		<!-- Width -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id('width')); ?>">Choose Widget Width:</label>
			<select id="<?php echo esc_html($this->get_field_id('width')); ?>" name="<?php echo esc_html($this->get_field_name('width')); ?>" style="width:100%;">
				<option value='stand' <?php if ('stand' == $instance['width']) echo 'selected="selected"'; ?>>Standard</option>
				<option value='wide' <?php if ('wide' == $instance['width']) echo 'selected="selected"'; ?>>Wide</option>
			</select>
		</p>

		<!-- Enter Cat/Tag -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'enterslug' )); ?>">Enter Category/Tag Slug Name:</label>
			<input id="<?php echo esc_html($this->get_field_id( 'enterslug' )); ?>" name="<?php echo esc_html($this->get_field_name( 'enterslug' )); ?>" value="<?php echo esc_html($instance['enterslug']); ?>" style="width:90%;" />
		</p>

		<!-- Exclude -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'exclude' )); ?>">Exclude posts on rest of page:</label>
			<input type="checkbox" id="<?php echo esc_html($this->get_field_id( 'exclude' )); ?>" name="<?php echo esc_html($this->get_field_name( 'exclude' )); ?>" <?php checked( (bool) esc_html($instance['exclude']), true ); ?> />
		</p>

		<!-- Background Color -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id('bgcolor')); ?>">Background Color:</label>
			<select id="<?php echo esc_html($this->get_field_id('bgcolor')); ?>" name="<?php echo esc_html($this->get_field_name('bgcolor')); ?>" style="width:100%;">
				<option value='none' <?php if ('none' == $instance['bgcolor']) echo 'selected="selected"'; ?>>None</option>
				<option value='white' <?php if ('white' == $instance['bgcolor']) echo 'selected="selected"'; ?>>White</option>
				<option value='gray' <?php if ('gray' == $instance['bgcolor']) echo 'selected="selected"'; ?>>Gray</option>
				<option value='black' <?php if ('black' == $instance['bgcolor']) echo 'selected="selected"'; ?>>Black</option>
				<option value='primary' <?php if ('primary' == $instance['bgcolor']) echo 'selected="selected"'; ?>>Primary Theme Color</option>
				<option value='secondary' <?php if ('secondary' == $instance['bgcolor']) echo 'selected="selected"'; ?>>Secondary Theme Color</option>
			</select>
		</p>

		<!-- Text Color -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id('txtcolor')); ?>">Widget Title Color:</label>
			<select id="<?php echo esc_html($this->get_field_id('txtcolor')); ?>" name="<?php echo esc_html($this->get_field_name('txtcolor')); ?>" style="width:100%;">
				<option value='standard' <?php if ('standard' == $instance['txtcolor']) echo 'selected="selected"'; ?>>Standard</option>
				<option value='white' <?php if ('white' == $instance['txtcolor']) echo 'selected="selected"'; ?>>White</option>
			</select>
		</p>

	<?php
	}
}

?>